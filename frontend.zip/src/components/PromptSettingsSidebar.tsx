// src/components/PromptSettingsSidebar.tsx
import React, { ChangeEvent } from 'react';

interface Prompt {
    id: string | null;
    name: string;
    description: string;
    instruction: string;
    parameters: { key: string; value: string; }[];
}

interface PromptSettingsSidebarProps {
    prompt: Prompt;
    onChange: (field: string, value: string) => void;
}

const PromptSettingsSidebar: React.FC<PromptSettingsSidebarProps> = ({ prompt, onChange }) => {
    const handleChange = (field: string) => (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        onChange(field, e.target.value);
    };
    return (
        <div className="prompt-settings">
            <h3>Настройки промпта</h3>
            <div>
                <label>Название * </label>
                <input
                    type="text"
                    value={prompt.name}
                    placeholder="Введите название промпта"
                    onChange={handleChange('name')}
                />
            </div>
            <div>
                <label>Описание</label>
                <textarea
                    value={prompt.description}
                    placeholder="Описание (необязательно)"
                    onChange={handleChange('description')}
                    rows={3}
                />
            </div>
            <div>
                <label>Инструкция * </label>
                <textarea
                    value={prompt.instruction}
                    placeholder="GPT будет использовать эту инструкцию как основу."
                    onChange={handleChange('instruction')}
                    rows={4}
                />
            </div>
            <div>
                <h4>Параметры генерации (необязательно)</h4>
                {prompt.parameters && prompt.parameters.length > 0 ? (
                    <ul>
                        {prompt.parameters.map((param, idx) => (
                            <li key={idx}>
                                {param.key}: {param.value}
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p>Нет дополнительных параметров.</p>
                )}
            </div>
        </div>
    );
};

export default PromptSettingsSidebar;
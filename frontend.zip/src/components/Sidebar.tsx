// src/components/Sidebar.tsx
import React from 'react';
import '../components/Sidebar.css';

interface Prompt {
    id: string | null;
    name: string;
    description: string;
    instruction: string;
    parameters: any[];
}

interface SidebarProps {
    user: any;
    prompts: Prompt[];
    currentPrompt: Prompt;
    setCurrentPrompt: (prompt: Prompt) => void;
    savePrompt: (userId: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ user, prompts, currentPrompt, setCurrentPrompt, savePrompt }) => {
    const handleSelect = (prompt: Prompt) => {
        setCurrentPrompt({ ...prompt });
    };
    const handleSaveToggle = () => {
        if (!user) {
            // Неавторизованный пользователь не может сохранять
            return;
        }
        savePrompt(user.id);
    };
    return (
        <aside className="sidebar">
            <div className="sidebar-header">AI Prompt Builder</div>
            <ul className="prompt-list">
                {user ? (
                    prompts.map((p) => (
                        <li
                            key={p.id || 'unsaved'}
                            onClick={() => handleSelect(p)}
                            className={p.id === currentPrompt.id ? 'active' : ''}>
                            {p.name || 'Без названия'}
                        </li>
                    ))
                ) : (
                    <li>{currentPrompt.name || 'Без названия'}</li>
                )}
            </ul>
            <div className="save-toggle">
                {user ? (
                    currentPrompt.id ? (
                        <button className="save-button" disabled>
                            ✔ Сохранено
                        </button>
                    ) : (
                        <button className="save-button" onClick={handleSaveToggle}>
                            💾 Включить сохранение
                        </button>
                    )
                ) : (
                    <button className="save-button" disabled>
                        🔒 Включить сохранение
                    </button>
                )}
            </div>
        </aside>
    );
};

export default Sidebar;
// src/components/Header.tsx
import React from 'react';
import '../components/Header.css';
import { useAuth } from '../hooks/useAuth';

const Header: React.FC = () => {
    const { user, login, logout } = useAuth();
    return (
        <header className="header">
            <div className="header-title"></div>
            <div className="header-auth">
                {user ? (
                    <button className="logout-button" onClick={logout}>
                        Выйти
                    </button>
                ) : (
                    <button className="login-button" onClick={login}>
                        Войти
                    </button>
                )}
            </div>
        </header>
    );
};

export default Header;
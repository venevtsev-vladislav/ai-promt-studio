// src/components/PromptEditor.tsx
import React, { useState } from 'react';
import './PromptEditor.css';
import PromptSettingsSidebar from './PromptSettingsSidebar';

interface Prompt {
    id: string | null;
    name: string;
    description: string;
    instruction: string;
    parameters: { key: string; value: string; }[];
}

interface PromptEditorProps {
    user: any;
    prompt: Prompt;
    setPrompt: (prompt: Prompt) => void;
}

const PromptEditor: React.FC<PromptEditorProps> = ({ user, prompt, setPrompt }) => {
    const [query, setQuery] = useState<string>('');
    const [output, setOutput] = useState<string>('');

    const handleChangePromptField = (field: string, value: string) => {
        setPrompt({ ...prompt, [field]: value });
    };

    const handleRunPrompt = async () => {
        if (!prompt.instruction || !query) return;
        // Здесь должен вызываться API для генерации ответа AI на основе prompt и запроса.
        // В данной версии выполняется симуляция вывода.
        setOutput(`Результат для запроса "${query}": (симуляция ответа AI)`);
    };

    return (
        <div className="prompt-editor">
            {/* Область тестирования промпта */}
            <div className="prompt-main">
                {!user && (
                    <div className="welcome">
                        <h2>Добро пожаловать в AI Prompt Builder</h2>
                        <p>Авторизуйтесь, чтобы сохранять свои промпты. Пока вы можете протестировать примерный промпт.</p>
                    </div>
                )}
                <div className="tester">
                    <input
                        type="text"
                        placeholder="Введите запрос..."
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                    />
                    <button onClick={handleRunPrompt} disabled={!query.trim()}>
                        Проверить
                    </button>
                </div>
                {output && (
                    <div className="output">
                        <h3>Результат:</h3>
                        <p>{output}</p>
                    </div>
                )}
            </div>
            {/* Панель настроек промпта */}
            <PromptSettingsSidebar prompt={prompt} onChange={handleChangePromptField} />
        </div>
    );
};

export default PromptEditor;
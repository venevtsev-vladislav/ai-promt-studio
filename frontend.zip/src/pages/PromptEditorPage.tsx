// src/components/PromptEditorPage.tsx
import React, { useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { usePrompts } from '../hooks/usePrompts';
import Header from '../components/Header';
import Sidebar from '../components/Sidebar';
import PromptEditor from '../components/PromptEditor';

const PromptEditorPage: React.FC = () => {
    const { user } = useAuth();
    const { prompts, currentPrompt, setCurrentPrompt, loadPrompts, savePrompt } = usePrompts();

    // Загружаем промпты при изменении пользователя (авторизация/выход)
    useEffect(() => {
        if (user) {
            loadPrompts(user.id);
        } else {
            // Если пользователь вышел, сбросить на промпт по умолчанию (пример)
            loadPrompts('');
        }
    }, [user]);

    return (
        <div className="app-container">
            <Header />
            <div className="main-content">
                <Sidebar
                    user={user}
                    prompts={prompts}
                    currentPrompt={currentPrompt}
                    setCurrentPrompt={setCurrentPrompt}
                    savePrompt={savePrompt}
                />
                <PromptEditor
                    user={user}
                    prompt={currentPrompt}
                    setPrompt={setCurrentPrompt}
                />
            </div>
        </div>
    );
};

export default PromptEditorPage;